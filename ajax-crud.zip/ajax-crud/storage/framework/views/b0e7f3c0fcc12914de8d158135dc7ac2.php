<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
	<!-- Boxicons -->
	<link href='https://unpkg.com/boxicons@2.0.9/css/boxicons.min.css' rel='stylesheet'>
	<!-- My CSS -->
	<link rel="stylesheet" href="<?php echo e(asset('css/style2.css')); ?>">
	<title>AdminHub</title>
</head>
<body>
<!-- SIDEBAR -->
<section id="sidebar">
    <a href="#" class="brand">
        <i class='bx bxs-smile'></i>
        <span class="text">AdminHub</span>
    </a>
    <ul class="side-menu top">
        <li class="active">
            <a href="<?php echo e(url('/')); ?>/dashboard">
                <i class='bx bxs-dashboard' ></i>
                <span class="text " Name="dashboard">Dashboard</span>
            </a>
        </li>
        <li>
            
            <a href="<?php echo e(url('/')); ?>/mystore">
                <i class='bx bxs-shopping-bag-alt' ></i>
                <span class="text" Name="mystore">My Store</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/')); ?>/orders">
                <i class='bx bxs-shopping-bag'></i>
                <span class="text" Name="orders">Orders</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/')); ?>/message">
                <i class='bx bxs-message-dots' ></i>
                <span class="text" Name="message">Message</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(url('/')); ?>/team">
                <i class='bx bxs-group' ></i>
                <span class="text" Name="team">Team</span>
            </a>
        </li>
    </ul>
    <ul class="side-menu">
        <li>
            <a href="<?php echo e(url('/')); ?>/settings">
                <i class='bx bxs-cog' ></i>
                <span class="text" Name="settings">Settings</span>
            </a>
        </li>
        <li>
            
            <form action="<?php echo e(url('/')); ?>/logout" method="post">
                    <?php echo csrf_field(); ?>
                <div>
                    <i class='bx bxs-log-out-circle' ></i>
                    <button type="submit">Logout</button>
               </div>
            </form>
            
        </li>
    </ul>
</section>
<!-- SIDEBAR -->


<section class="mystore">
    <div class=" div-mystore ">
        <button class="open-modal" type="button">
            <i class='bx bxs-add-to-queue'></i>
                <span>Add Item</span>
        </button> <br>
        <dialog class="item-info modal" id="modal1">
            <h2>Add Item</h2>
            <form  id="additem">
                <?php echo csrf_field(); ?>
                <div class="items">
                    <label for="title">Title</label>
                    <input type="text" id="title" name="title" required>
                </div>
                <div class="items">
                    <label for="price">Price</label>
                    <input type="text" id="price" name="price" required>
                </div>
                <div class="items">
                    <label for="image">File</label>
                    <input type="file" id="filename" name="image" required>
                </div>
                <div class="item">
                    <label for="description">Description</label>
                    <textarea id="description" name="description" required></textarea>
                </div>
                <div class="items">
                    <button class="close-modal">Cancle</button>
                    <button type="submit" class="button-modal submit">Save</button>
                </div>
            </form>
        </dialog>
        
        <table class="table">
            <thead>
                <tr>
                <th>Product_ID</th>
                <th>Name</th>
                <th>Price</th>
                <th>Image</th>
                <th>Description</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
                <?php
                    $i=1;
                ?>
               <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($row->product_Name); ?></td>
                    <td><?php echo e($row->price); ?></td>
                    <td>
                        <img src="<?php echo e(asset($row->image)); ?>" width="80" height="80" alt="">
                    </td>
                    <td><?php echo e($row->description); ?></td>
                    <td>
                     <button class="update-modal edit" data-id=<?php echo e($row->product_ID); ?>>Update</button>
                     <button class="delete-modal">Delete</button>
                </td>
               </tr>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          
          <section class="edit">
            <dialog class="item-info updateModal">
                <h2>Update Item</h2>
                <form action="">
                    <div class="items">
                        <label for="ttl">Title</label>
                        <input type="text" name="ttl">
                    </div>
                    <div class="items">
                        <label for="prc">Price</label>
                        <input type="text" name="prc">
                    </div>
                    <div class="items">
                        <label for="image">File</label>
                        <input type="file" name="image">
                    </div>
                    <div class="item">
                        <label for="description">Description</label>
                        <textarea name="description"></textarea>
                    </div>
                    <div class="items">
                        <button class="cancle-modal">Cancle</button>
                        <button type="submit" class="button-modal">Save</button>
                    </div>
                </form>
            </dialog>
          </section>
    </div>
</section>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

</body>



</html>
<script>
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});
</script>
<script>
    const openButton = document.querySelector(".open-modal");
    const modalButton = document.querySelector(".modal");
    const closeButton = document.querySelector(".close-modal");

    openButton.addEventListener('click', () => {

        modalButton.showModal(); // Opens a modal
});
    closeButton.addEventListener('click', () => {

        modalButton.close(); // Opens a modal
});


</script>
<script>
    $(document).ready(function(){
        //add item
       $(document).on('click','.submit',function(e){
        e.preventDefault();
        // alert('submitted');
        formData = new FormData($('#additem')[0]);
        // alert('submitted');

        $.ajax({
            method:'POST',
            url:'/store/item',
            // url:'<?php echo e(url('/')); ?>/storeItem',
            data:formData,
            cache:false,
            processData: false,
            contentType: false,
            success:function(response){
            //   $('.alert').show();
            //   $('.alert').html('Item added successfully.');
              $('#additem')[0].reset();
            //   $('#modal1').modal('hide'); //bootstrap hide
              $('#modal1')[0].close();      // dialog hide
              $('.table').load(location.href+' .table');
            },
        });
       });
        //add item end

        //show data in edit modal
        $(document).on('click','.edit',function(e){
            e.preventDefault();
            let id = $(this).data('id');
            // alert(id);
            // $('#editItemModal').modal('show');
               // Event delegation for "Open" buttons inside modals
            // Get the corresponding modal
            var modal = $(this).next(".updateModal")[0];
            modal.showModal();



            $.ajax({
                method:'GET',
                url:'/edit/item/'+id,
                success:function(response){
                      //console.log(response);
                      $('#e_name').val(response.item.name);
                      $('#e_price').val(response.item.price);
                      $('#edit_id').val(id);
                },
            });
        });
         // Event delegation for "Close" buttons inside modals
         $(document).on("click", ".cancle-modal", function () {
            var modal = $(this).closest(".updateModal")[0];
            modal.close();
        });

        //show data in edit modal end

        //update item
        $(document).on('click','.update',function(e){
            e.preventDefault();
            let id = $('#edit_id').val();

            let editData = new FormData($('#editItemForm')[0])

            $.ajax({
            method:'POST',
            url:'/update/item/'+id,
            data:editData,
            cache:false,
            processData: false,
            contentType: false,

            success:function(response){
              $('.alert').show();
              $('.alert').html('Item updated successfully.');
              $('#editItemForm')[0].reset();
              $('#editItemModal').modal('hide');
              $('.table').load(location.href+' .table');
            },
        });
        });
        //update item end

        //delete item
        $(document).on('click','.delete',function(e){
            e.preventDefault();
            let id = $(this).data('id');
            //alert(id);
           if(confirm('Are you sure to delete this item permanently????')){
            $.ajax({
            method:'GET',
            url:'/delete/item/'+id,
            success:function(response){
              $('.alert').show();
              $('.alert').html('Item deleted successfully.');
              $('.table').load(location.href+' .table');
            },
        });
           }
        });
        // delete item end
    });
</script>
<?php /**PATH C:\xampp\htdocs\ajax-crud\resources\views/mystore.blade.php ENDPATH**/ ?>