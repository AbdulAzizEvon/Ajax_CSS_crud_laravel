<?php

namespace App\Http\Controllers;

use App\Models\Products;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class productController extends Controller
{
    // public function addproduct(Request $request){
    //     $validatedData =$request->validate([
    //         'file' => 'required|mimes:doc,docx,csv,txt,xlx,xls,pdf|max:2048',
    //         ]);
    //     // $file = $request->file('filename');
    //     $file = Input::file('filename');
    //     dd($file);
    //     // $fileName = time().' '.$file->getClientOrginalName();
    //     $fileName = uniqid() . $file->getClientOriginalName() . '.' . $file->getClientOriginalExtension();
    //     $filepath = $file->storageAs('images',$fileName,'public');
    //     products::create([
    //         'product_Name' => $request->title,
    //         'price' => $request->price,
    //         'image' => $filepath,
    //         'description' => $request->description
    //     ]);
    //     return response()->json(['res'=>'information submit successfully']);
    // }
    public function index(){
        $items =Products::orderBy('product_ID','desc')->get();
        // $items = DB::table('products')->orderBy('id','desc')->get();
        // $data = DB::table('products')->get();
        // return $items; exit();
        // dd('items');
        return view('mystore',compact('items'));
        // return view('mystore',compact('items'));
    }//end method

    //store item
    public function storeItem(Request $request){
        //image uplaod
        if($request->image){
            $image = $request->image;
            $imageName = rand().'.'.$image->getClientOriginalName();
            $image->move('upload/', $imageName);

            $imageUrl = 'upload/'.$imageName;
        }

        //data insert
        $item = new Products();

        $item->product_Name = $request->title;
        $item->price = $request->price;
        $item->image = $imageUrl;
        $item->description = $request->description;
        $item->save();
    }//end method
}
